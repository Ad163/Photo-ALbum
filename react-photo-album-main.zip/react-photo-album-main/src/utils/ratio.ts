export default function ratio({ width, height }: { width: number; height: number }) {
    return width / height;
}
