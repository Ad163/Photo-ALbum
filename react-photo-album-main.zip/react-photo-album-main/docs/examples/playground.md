# Playground

Here is an interactive playground to test various parameters in real-time.

## Live Demo

<Playground />

## CodeSandbox

<CodeSandboxLink suffix="playground" file="src/App.tsx" />

## Source Code

<GitHubLink suffix="playground" />
