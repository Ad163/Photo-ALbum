<!-- Thank you so much for your PR, your contribution is appreciated! ❤️ -->

- [ ] I have followed the 'Sending a Pull Request' section of the [contributing guide](https://github.com/igordanchenko/react-photo-album/blob/main/CONTRIBUTING.md#sending-a-pull-request)
